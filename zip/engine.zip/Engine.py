from flask import Flask, request, render_template, redirect, url_for, session, flash
import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import re

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this for production
DATABASE = 'app.db'

# -------- DATABASE SETUP --------
def init_db():
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        c = conn.cursor()
        c.execute('''CREATE TABLE users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        password TEXT NOT NULL,
                        email TEXT,
                        verified INTEGER DEFAULT 0,
                        referral_code TEXT UNIQUE,
                        referred_by TEXT
                    )''')

        c.execute('''CREATE TABLE users 
                       (id INTEGER PRIMARY KEY AUTOINCREMENT,
                       username TEXT UNIQUE NOT NULL,
                       password TEXT NOT NULL,
                       email TEXT,
                       verified INTEGER DEFAULT 0,
                       referral_code TEXT UNIQUE,
                       referred_by TEXT,
                       profile_image TEXT
                   )''')

        c.execute('''CREATE TABLE transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        type TEXT,
                        amount REAL,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY(user_id) REFERENCES users(id)
                    )''')
        conn.commit()
        conn.close()

# -------- DATABASE CONNECTION --------
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# -------- ROUTES --------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            data = request.get_json()
            
            # Validate required fields
            required_fields = ['fullName', 'username', 'email', 'password', 
                              'phone', 'idNumber', 'gender', 'dob', 'address', 'country']
            errors = {}
            
            for field in required_fields:
                if not data.get(field):
                    errors[field] = f"{field} is required"
            
            # Additional validations
            if not errors.get('email') and not re.match(r'^[^\s@]+@[^\s@]+\.[^\s@]+$', data['email']):
                errors['email'] = "Invalid email format"
            
            if not errors.get('password') and len(data['password']) < 8:
                errors['password'] = "Password must be at least 8 characters"
            
            if not errors.get('phone') and not re.match(r'^\+?[\d\s\-]{10,15}$', data['phone']):
                errors['phone'] = "Invalid phone number format"
            
            if errors:
                return jsonify({
                    'success': False,
                    'errors': errors
                }), 400
            
            # Check if username or email already exists
            conn = get_db()
            existing_user = conn.execute(
                'SELECT * FROM users WHERE username = ? OR email = ?',
                (data['username'], data['email'])
            ).fetchone()
            
            if existing_user:
                conn.close()
                field = 'username' if existing_user['username'] == data['username'] else 'email'
                return jsonify({
                    'success': False,
                    'errors': {
                        field: f"This {field} is already registered"
                    }
                }), 400
            
            # Hash password
            hashed_password = generate_password_hash(data['password'])
            
            # Generate referral code
            referral_code = str(uuid.uuid4())[:8]
            
            # Insert new user
            conn.execute(
                '''INSERT INTO users 
                (username, password, email, full_name, phone, id_number, 
                 gender, dob, address, country, referral_code, verified)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (data['username'], hashed_password, data['email'], data['fullName'],
                 data['phone'], data['idNumber'], data['gender'], data['dob'],
                 data['address'], data['country'], referral_code, 0)
            )
            conn.commit()
            conn.close()
            return jsonify({
                'success': True,
                'message': 'Registration successful'
            })
            
        except Exception as e:
            print(f"Registration error: {str(e)}")
            return jsonify({
                'success': False,
                'message': 'An error occurred during registration'
            }), 500
          return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()  # Get data as JSON instead of form-data
    username = data.get('username')
    password = data.get('password')

    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    conn.close()

    if user and check_password_hash(user['password'], password):
        # Return JSON response (matches frontend expectations)
        return jsonify({
            'success': True,
            'fica_status': 'approved' if user['verified'] else 'unverified'
        })
    else:
        return jsonify({'success': False}
        return render_template('Login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('Dashboard.html')

@app.route('/dashboard-data')
def dashboard_data():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401  # User not logged in

    conn = get_db()
    
    # Get user's balance (sum of deposits - withdrawals)
    balance = conn.execute('''
        SELECT SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END) 
        FROM transactions WHERE user_id = ?
    ''', (session['user_id'],)).fetchone()[0] or 0.0
    
    # Get last 5 transactions
    activities = conn.execute('''
        SELECT type, amount, timestamp as date 
        FROM transactions 
        WHERE user_id = ? 
        ORDER BY timestamp DESC 
        LIMIT 5
    ''', (session['user_id'],)).fetchall()
    
    conn.close()
    
    return jsonify({
        'balance': balance,
        'activities': [dict(activity) for activity in activities]
    })
 
@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('Profile.html')

@app.route('/get_profile', methods=['GET'])
def get_profile():
    if 'user_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    conn = get_db()
    user = conn.execute('SELECT username, email FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    balance = conn.execute('''
        SELECT COALESCE(SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END), 0)
        FROM transactions WHERE user_id = ?
    ''', (session['user_id'],)).fetchone()[0]
    conn.close()

    return jsonify({
        'name': user['username'],
        'email': user['email'],
        'balance': balance
    })

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    data = request.get_json()
    new_email = data.get('email')
    new_password = data.get('password')

    if not new_email or not new_password:
        return jsonify({'success': False, 'message': 'Missing fields'}), 400

    hashed_password = generate_password_hash(new_password)

    conn = get_db()
    try:
        conn.execute('UPDATE users SET email = ?, password = ? WHERE id = ?', 
                     (new_email, hashed_password, session['user_id']))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        print("Profile update error:", str(e))
        return jsonify({'success': False, 'message': 'Failed to update'})
    finally:
        conn.close()

@app.route('/deposit', methods=['POST'])
def deposit():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    data = request.get_json()
    method = data.get('method')
    amount = data.get('amount')

    # Validate input
    if not method or method not in ['crypto', 'bank_transfer', 'mobile_money']:
        return jsonify({'success': False, 'message': 'Invalid deposit method'}), 400

    try:
        amount = float(amount)
        if amount < 200:
            return jsonify({'success': False, 'message': 'Minimum deposit is R200'}), 400
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Invalid amount'}), 400

    conn = get_db()
    try:
        conn.execute(
            'INSERT INTO transactions (user_id, type, amount) VALUES (?, ?, ?)',
            (session['user_id'], 'deposit', amount)
        )
        conn.commit()

        # 🧮 Real-time balance update
        balance = conn.execute('''
            SELECT SUM(CASE WHEN type = 'deposit' THEN amount ELSE -amount END)
            FROM transactions WHERE user_id = ?
        ''', (session['user_id'],)).fetchone()[0] or 0.0

        return jsonify({
            'success': True,
            'message': 'Deposit submitted successfully.',
            'newBalance': balance
        })

    except Exception as e:
        print("DB Error:", e)
        return jsonify({'success': False, 'message': 'Something went wrong. Try again.'}), 500
    finally:
        conn.close()
        return render_template('Deposit.html')

@app.route('/withdraw', methods=['POST'])
def withdraw():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    data = request.get_json()
    method = data.get('method')
    destination = data.get('destination')
    amount = data.get('amount')

    # Validate
    if not method or method not in ['crypto', 'bank', 'mobile']:
        return jsonify({'success': False, 'message': 'Invalid withdrawal method'}), 400

    try:
        amount = float(amount)
        if amount < 1:
            return jsonify({'success': False, 'message': 'Minimum withdrawal is R1'}), 400
    except (ValueError, TypeError):
        return jsonify({'success': False, 'message': 'Invalid amount'}), 400

    if not destination:
        return jsonify({'success': False, 'message': 'Withdrawal destination is required'}), 400

    # Save withdrawal request
    conn = get_db()
    try:
        conn.execute(
            'INSERT INTO transactions (user_id, type, method, destination, amount, status) VALUES (?, ?, ?, ?, ?, ?)',
            (session['user_id'], 'withdrawal', method, destination, amount, 'pending')
        )
        conn.commit()
        return jsonify({'success': True, 'message': 'Withdrawal submitted'})
    except Exception as e:
        print("DB error:", e)
        return jsonify({'success': False, 'message': 'Database error'}), 500
    finally:
        conn.close()
    return render_template('Withdrawal.html')

@app.route('/transactions')
def transactions():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    txns = conn.execute('SELECT * FROM transactions WHERE user_id = ? ORDER BY timestamp DESC',
                        (session['user_id'],)).fetchall()
    conn.close()
    return render_template('Transactions.html', transactions=txns)

@app.route('/verify', methods=['POST'])
def verify():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401

    if 'idDocument' not in request.files or 'proofAddress' not in request.files:
        return jsonify({'success': False, 'message': 'Missing required documents'}), 400

    id_file = request.files['idDocument']
    proof_file = request.files['proofAddress']

    # Check file types
    allowed_exts = {'pdf', 'png', 'jpg', 'jpeg'}
    def is_valid(file):
        return '.' in file.filename and file.filename.rsplit('.', 1)[1].lower() in allowed_exts

    if not is_valid(id_file) or not is_valid(proof_file):
        return jsonify({'success': False, 'message': 'Invalid file type. Use JPG, PNG, or PDF.'}), 400

    # Save files
    upload_path = os.path.join('static', 'fica')
    os.makedirs(upload_path, exist_ok=True)
    id_filename = f"id_{session['user_id']}_{secure_filename(id_file.filename)}"
    proof_filename = f"proof_{session['user_id']}_{secure_filename(proof_file.filename)}"
    
    id_path = os.path.join(upload_path, id_filename)
    proof_path = os.path.join(upload_path, proof_filename)
    
    id_file.save(id_path)
    proof_file.save(proof_path)

    # Mark user as pending verified (in real system, you’d have a "pending" state and admin approval)
    conn = get_db()
    conn.execute('UPDATE users SET verified = 1 WHERE id = ?', (session['user_id'],))
    conn.commit()
    conn.close()

    return jsonify({'success': True})
    return render_template('Verification.html')

@app.route('/invitation')
def invitation():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    referrals = conn.execute('SELECT * FROM users WHERE referred_by = ?', (user['referral_code'],)).fetchall()
    conn.close()
    return render_template('Invitation.html', user=user, referrals=referrals)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/admin/verifications')
def admin_verifications():
    # Optional: check if current user is admin
    conn = get_db()
    users = conn.execute('SELECT * FROM users WHERE verified = ?', ('pending',)).fetchall()
    conn.close()
    return render_template('AdminVerifications.html', users=users)

@app.route('/admin/approve/<int:user_id>', methods=['POST'])
def admin_approve(user_id):
    conn = get_db()
    conn.execute('UPDATE users SET verified = ? WHERE id = ?', ('approved', user_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'User approved'})

@app.route('/admin/reject/<int:user_id>', methods=['POST'])
def admin_reject(user_id):
    conn = get_db()
    conn.execute('UPDATE users SET verified = ? WHERE id = ?', ('rejected', user_id))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'message': 'User rejected'})

# -------- RUN APP --------
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
